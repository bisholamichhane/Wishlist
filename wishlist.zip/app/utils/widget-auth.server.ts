/**
 * Widget auth utility.
 *
 * The storefront Liquid extension generates a token by HMAC-signing the
 * shop domain with your SHOPIFY_API_SECRET. This file verifies that token
 * on incoming widget API requests so we know the call originated from a
 * legitimate storefront embed of your app.
 *
 * In Liquid (inside your theme extension):
 *   {{ shop.permanent_domain | hmac_sha256: shop.metafields.custom.wishlist_widget_secret }}
 *
 * For simplicity during development you can use the API secret directly,
 * but in production store a separate per-shop secret in a metafield.
 */

import { createHmac } from "crypto";

export function generateWidgetToken(shopDomain: string): string {
  const secret = process.env.SHOPIFY_API_SECRET!;
  return createHmac("sha256", secret).update(shopDomain).digest("hex");
}

export function verifyWidgetToken(shopDomain: string, token: string): boolean {
  const expected = generateWidgetToken(shopDomain);
  // Constant-time comparison to prevent timing attacks
  if (expected.length !== token.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) {
    diff |= expected.charCodeAt(i) ^ token.charCodeAt(i);
  }
  return diff === 0;
}
